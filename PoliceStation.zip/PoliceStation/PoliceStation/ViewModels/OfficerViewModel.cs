﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Input;
using GalaSoft.MvvmLight.Command;
using PoliceStation.Models;
using PoliceStation.Services;

namespace PoliceStation.ViewModels
{
    public class OfficerViewModel : INotifyPropertyChanged
    {
        private QueryService _queryService = new QueryService();
        private string selectedRank;
        private string lastNameFilter;

        public ObservableCollection<PoliceOfficer> Officers { get; set; }
        public ICommand FilterCommand { get; private set; }
        public ICommand UpdateOfficerCommand { get; private set; }
        public ICommand AddOfficerCommand { get; private set; }

        private PoliceOfficer selectedOfficer;

        public OfficerViewModel()
        {
            Officers = new ObservableCollection<PoliceOfficer>();
            FilterCommand = new RelayCommand(ExecuteFilter);
            AddOfficerCommand = new RelayCommand(AddOfficer);
            UpdateOfficerCommand = new RelayCommand(UpdateOfficer, CanExecuteUpdateOfficer);
        }

        public string SelectedRank
        {
            get => selectedRank;
            set { selectedRank = value; OnPropertyChanged(nameof(SelectedRank)); }
        }

        public string LastNameFilter
        {
            get => lastNameFilter;
            set { lastNameFilter = value; OnPropertyChanged(nameof(LastNameFilter)); }
        }

        public PoliceOfficer SelectedOfficer
        {
            get => selectedOfficer;
            set { selectedOfficer = value; OnPropertyChanged(nameof(SelectedOfficer)); }
        }

        private void ExecuteFilter()
        {
            DataTable results = _queryService.GetOfficersWithFilter(SelectedRank, LastNameFilter);
            Officers.Clear();
            foreach (DataRow row in results.Rows)
            {
                Officers.Add(new PoliceOfficer
                {
                    OfficerId = Convert.ToInt32(row["OfficerId"]),
                    FirstName = row["FirstName"].ToString(),
                    LastName = row["LastName"].ToString(),
                    Rank = row["Rank"].ToString()
                });
            }
        }

        private void AddOfficer()
        {
            var newOfficer = new PoliceOfficer { FirstName = "New", LastName = "Officer", Rank = "Rookie" };
            DatabaseService dbService = new DatabaseService();
            dbService.AddOfficer(newOfficer);
            Officers.Add(newOfficer);  // Обновляем ObservableCollection
        }

        private void UpdateOfficer()
        {
            if (SelectedOfficer != null)
            {
                DatabaseService dbService = new DatabaseService();
                dbService.UpdateOfficer(SelectedOfficer);
            }
        }

        private bool CanExecuteUpdateOfficer()
        {
            return SelectedOfficer != null;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}