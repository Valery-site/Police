﻿using System.Collections.ObjectModel;
using PoliceStation.Models;
using PoliceStation.Services;

namespace PoliceStation.ViewModels
{
    public class CaseViewModel
    {
        public ObservableCollection<Case> Cases { get; set; }

        public CaseViewModel()
        {
            // В реальном приложении здесь будет код для загрузки данных из базы
            Cases = new ObservableCollection<Case>
            {
                new Case { CaseId = 1, CaseNumber = "C001", Description = "Robbery", OfficerId = 1 },
                new Case { CaseId = 2, CaseNumber = "C002", Description = "Assault", OfficerId = 2 }
            };
        }
    }
}