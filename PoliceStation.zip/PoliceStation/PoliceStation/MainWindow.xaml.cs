﻿using System.Windows;
// Убедитесь, что добавлены следующие директивы using:
using PoliceStation.Views;  // Добавьте это, если OfficerView и CaseView в этом пространстве имен

namespace PoliceStation
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnOfficers_Click(object sender, RoutedEventArgs e)
        {
            OfficerView officerView = new OfficerView();  // Проверьте, что OfficerView корректно определён
            officerView.Show();
        }

        private void BtnCases_Click(object sender, RoutedEventArgs e)
        {
            CaseView caseView = new CaseView();  // Проверьте, что CaseView корректно определён
            caseView.Show();
        }
    }
}