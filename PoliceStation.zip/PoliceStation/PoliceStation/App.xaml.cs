﻿using System.Windows;

namespace PoliceStation
{
    public partial class App : Application
    {
        // Дополнительные конфигурации можно добавлять здесь
    }
}