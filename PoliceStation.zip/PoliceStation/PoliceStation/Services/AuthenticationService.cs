﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoliceStation.Services
{
    public class AuthenticationService
    {
        public bool Authenticate(string username, string password)
        {
            // Здесь должна быть логика проверки имени пользователя и пароля
            // Например, запрос в базу данных для проверки
            return username == "admin" && password == "admin";
        }
    }
}
