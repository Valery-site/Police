﻿using System.Data;
using System.Data.OleDb;
using PoliceStation.Models;
using System.Collections.Generic;

namespace PoliceStation.Services
{
    public class DatabaseService
    {
        private readonly string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=police.accdb;";

        public List<PoliceOfficer> GetOfficers()
        {
            var officers = new List<PoliceOfficer>();
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand("SELECT * FROM Officers", connection);
                OleDbDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    officers.Add(new PoliceOfficer
                    {
                        OfficerId = int.Parse(reader["OfficerId"].ToString()),
                        FirstName = reader["FirstName"].ToString(),
                        LastName = reader["LastName"].ToString(),
                        Rank = reader["Rank"].ToString()
                    });
                }
            }
            return officers;
        }

        public void UpdateOfficer(PoliceOfficer officer)
        {
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand("UPDATE Officers SET FirstName = ?, LastName = ?, Rank = ? WHERE OfficerId = ?", connection);
                command.Parameters.Add("?", OleDbType.VarChar).Value = officer.FirstName;
                command.Parameters.Add("?", OleDbType.VarChar).Value = officer.LastName;
                command.Parameters.Add("?", OleDbType.VarChar).Value = officer.Rank;
                command.Parameters.Add("?", OleDbType.Integer).Value = officer.OfficerId;
                command.ExecuteNonQuery();
            }
        }

        public void DeleteOfficer(int officerId)
        {
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand("DELETE FROM Officers WHERE OfficerId = ?", connection);
                command.Parameters.Add("?", OleDbType.Integer).Value = officerId;
                command.ExecuteNonQuery();
            }
        }

        public void AddOfficer(PoliceOfficer officer)
        {
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand("INSERT INTO Officers (FirstName, LastName, Rank) VALUES (?, ?, ?)", connection);
                command.Parameters.Add("?", OleDbType.VarChar).Value = officer.FirstName;
                command.Parameters.Add("?", OleDbType.VarChar).Value = officer.LastName;
                command.Parameters.Add("?", OleDbType.VarChar).Value = officer.Rank;
                command.ExecuteNonQuery();
            }
        }
    }
}