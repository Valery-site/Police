﻿using System.Data;
using System.Data.OleDb;

namespace PoliceStation.Services
{
    public class QueryService
    {
        private readonly string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=path_to_your_database.accdb;";

        public DataTable GetOfficersWithFilter(string rank, string lastName)
        {
            string query = $"SELECT * FROM Officers WHERE Rank = '{rank}' AND LastName LIKE '%{lastName}%'";
            return ExecuteQuery(query);
        }

        public DataTable GetCasesByDescription(string keyword)
        {
            string query = $"SELECT * FROM Cases WHERE Description LIKE '%{keyword}%'";
            return ExecuteQuery(query);
        }

        private DataTable ExecuteQuery(string query)
        {
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);
                DataTable results = new DataTable();
                adapter.Fill(results);
                return results;
            }
        }
    }
}