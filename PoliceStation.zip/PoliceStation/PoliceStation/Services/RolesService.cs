﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoliceStation.Services
{
    public class RolesService
    {
        // Пример простого хранилища ролей (в реальном приложении данные будут извлекаться из базы данных)
        private Dictionary<string, string> userRoles = new Dictionary<string, string>
        {
            { "admin", "Administrator" },
            { "user", "User" }
        };

        public string GetUserRole(string username)
        {
            if (userRoles.ContainsKey(username))
                return userRoles[username];
            return "Guest";  // Роль по умолчанию
        }
    }
}